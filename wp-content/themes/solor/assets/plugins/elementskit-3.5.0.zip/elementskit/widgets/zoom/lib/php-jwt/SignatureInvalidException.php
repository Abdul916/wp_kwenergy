<?php
namespace ElementsKit\Firebase\JWT;

class SignatureInvalidException extends \UnexpectedValueException
{
}
